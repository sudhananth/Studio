export interface UserInfo {
    UserId: number;
    UserName: string;
    UserTypeId: string;
    UserEmail: string;
}