'use strict';
let URL = "http://studioapi.merlioninfotech.com/api/";
export const  studioapi = Object.freeze({
    URL: URL   
});